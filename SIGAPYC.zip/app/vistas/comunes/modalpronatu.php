
<!-- Message Modal Propietario Narutal -->
<div class="modal fade" id="msgModalProNatu" tabindex="-1" role="dialog" aria-labelledby="msgModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header badge-primary" style="background-color: #c2c9ce !important;">
                <h5 class="modal-title"><i class="fa fa-comment" alt="mensaje"></i>&nbsp;Mensaje</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="row">
                    <div class="col-md-12">
                        <span id="spanMsgProNatu">&nbsp;</span>
                    </div>
                </div>
                <br/>
                <div class="row">
                    <div class="col-md-6">
                        <span id="spanApoderado">&nbsp;</span>
                        <span id="spanInmueble">&nbsp;</span>
                    </div>
                    
                </div>

            </div>
                     
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>