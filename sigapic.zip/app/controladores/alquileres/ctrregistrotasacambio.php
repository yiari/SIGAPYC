<?php

/*
|----------------------------------------
| INCLUYO LA CLASE CORRESPONDIENTE
|----------------------------------------
*/
include_once '../../../app/modelos/alquileres/mdlregistrotasacambio.php';


/*
|---------------------------------------------------------------
| LAS CLASES SE DEBEN LLAMAR EXACTAMENTE IGUAL QUE SU ARCHIVO
|---------------------------------------------------------------
*/

class ctrregistrotasacambio{

    //protected string $tabla;

    public function __construct()
    {
        /*
        |-------------------------------------------------
        | ESTO ES UN CONSTRUCTOR CUANDO SE CREA LA CLASE 
        |-------------------------------------------------
        */ 
    }

     public function registrar($datos){

            $tabla = "tasa_cambio";
           

            $modelo =  new mdlregistrotasacambio();
            $respuesta = $modelo->registrar($tabla,$datos);

            return $respuesta;

    }

    public function consultartasa(){

        $modelo =  new mdlregistrotasacambio();
        $respuesta = $modelo->consultartasa();

        return $respuesta;

}


}