  
            
                
                <div class="container">

                   
                        <div class="container-fluid px-4"> 
                           <div class="logo"><img src="img/logo.png" class="img-responsive" alt="" width="600px" height="300px"></div>
                           
                            <div class="row">
                                    <div class="col-xl-4 col-md-4">
                                        <div class="card bg-primary text-white mb-4">
                                        <a href="alquileres.php" button type= "submit" class="btn btn-primary">ALQUILERES</button></a>  
                                        </div>
                                    </div>
                                    <div class="col-xl-4 col-md-4">
                                        <div class="card bg-primary text-white mb-4">
                                        <a href="finanzas.php" button type= "submit" class="btn btn-primary">FINANZAS</button></a>  
                                        </div>
                                    </div>
                                   
                             </div>


                             <div class="row">
                                    
                                    <div class="col-xl-4 col-md-4">
                                        <div class="card bg-primary text-white mb-4">
                                        <a href="configuraciones.php" button type= "submit" class="btn btn-primary">CONFIGURACIONES</button></a>                                   
                                        </div>
                                    </div>
                                    <div class="col-xl-4 col-md-4">
                                        <div class="card bg-primary text-white mb-4">
                                        <a href="reportes.php" button type= "submit" class="btn btn-primary">REPORTES</button></a>                                     
                                        </div>
                                    </div>
                             </div>
                            </div>

                </div>
       

   

