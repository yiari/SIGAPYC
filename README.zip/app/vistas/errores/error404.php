<div class="text-center">
    <h1>404</h1>
    <p>Pagina no encontrada</p>

<a href="index.php?paginas=registro" class="btn btn-primary">Volver</a>
</div>