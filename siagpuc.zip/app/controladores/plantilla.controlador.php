<?php


class controladorPlantilla{

/*  llamada la la plantilla*/

public function ctrtraeplantilla(){

/* include  se utiliza para invocar el archivo que contiene codigo html-pgp */ 

include "app/vistas/inicio.php";

}


}