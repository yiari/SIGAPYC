function inicio(){

   
    cargarRepresentanteLegal();
    cargarinquilino();
    


}



$(document).ready(function() {


    inicio();



});