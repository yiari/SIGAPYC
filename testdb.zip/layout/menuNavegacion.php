<div class="card">
        <div class="card-header">

            <ol>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/alquileres"> <i class="fa fa-home me-2"></i> Inicio</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/propietarios"> <i class="fa fa-users"></i> Propietarios</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/inmueblestodo"> <i class="fa fa-building-o"></i> Inmuebles</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/inquilinos"> <i class="fa fa-address-book-o"></i> Inquilinos</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/contratos"> <i class="fa fa-copy"></i> Contrato</a> 

                <!--<a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/aviso_cobro"><i class="fa fa-exclamation-circle"></i> Aviso de cobro</a> 
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/consulta_gastos_especiales"><i class="fa fa-money"></i> Gastos especiales</a> 
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/consulta_gastos_especiales"><i class="fa fa-money"></i> Pedidos Y Recibos</a> -->
               

                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-exclamation-circle"></i> Aviso de cobro
                    </button>
                    <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="index.php?url=app/vistas/alquileres/tasa_cambio">Tasa de cambio BCV</a></li>
                    <li><a class="dropdown-item" href="index.php?url=app/vistas/alquileres/aviso_cobro"> Gestionar Aviso de cobro</a></li>
                    <li><a class="dropdown-item" href="index.php?url=app/vistas/alquileres/consulta_gastos_especiales">Listas de Gastos especiales</a></li>
                    <li><a class="dropdown-item" href="index.php?url=app/vistas/alquileres/recibo_pedidos">Lista Pedidos Y Recibos</a></li>
                    </ul>
                </div>
                
                
            </ol>


            


           

            
    </div>

    
        

