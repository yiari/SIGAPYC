<div class="card">
        <div class="card-header">

            <ol>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/alquileres"> <i class="fa fa-home me-2"></i> Inicio</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/propietarios"> <i class="fa fa-users"></i> Propietarios</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/inmuebles"> <i class="fa fa-building-o"></i> Inmuebles</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/inquilinos"> <i class="fa fa-address-book-o"></i> Inquilinos</a>
                <a type="button" class="btn btn-primary" href="index.php?url=app/vistas/alquileres/contratos"> <i class="fa fa-copy"></i> Contrato</a> 
            </ol>
        </div>
    </div>

    
        

