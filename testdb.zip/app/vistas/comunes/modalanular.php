<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header badge-danger">
                <h5 class="modal-title" id="deleteModalLabel">Anulacion del  Recibo</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Esta seguro que desea anular el recibo ?</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">si</button>
                <a href="#" class="btn btn-danger" id="spanDeleteOk" data-bs-dismiss="modal">No</a>
                <span id="spanDelete">&nbsp;</span>
            </div>
        </div>
    </div>
</div>

