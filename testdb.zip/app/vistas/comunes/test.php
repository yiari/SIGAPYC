<!DOCTYPE html>
<html>
   <head>
      <title>La belleza de la vida</title>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
   </head>
   <body>
      <h1>La belleza de la vida</h1>
      <p>Esta mañana me desperté sientiéndome diferente...</p>
      <h1><span id="resultado"></span></h1>
      
   </body>

   

   <script src="../../../js/comunes/generadorcodigos.js"></script>


</html>


